# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - <%= new Date().toISOString().split('T')[0] %>

### Added
- Initial release
- Basic SDK structure
- TypeScript support

<!-- Add your changes here using this format:

## [1.1.0] - YYYY-MM-DD

### Added
- New feature

### Changed
- Updated feature

### Fixed
- Bug fix

### Removed
- Deprecated feature
--> 