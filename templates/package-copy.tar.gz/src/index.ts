// Main exports for <%= simpleName %>
export { <%= className %> } from './__simpleName__Sdk';
export * from './schemas';

// Example usage:
// import { <%= className %> } from '<%= packageName %>';
// const sdk = new <%= className %>({ apiKey: 'your-key' });
