import { SQSHandler, SQSEvent } from 'aws-lambda';

export const handler: SQSHandler = async (event: SQSEvent) => {
    for (const record of event.Records) {
        try {
            const body = JSON.parse(record.body);
            console.log('Processing message:', body);
            // Add your SQS message processing logic here
        } catch (error) {
            console.error('Error processing message:', error);
            // Decide if you want to re-queue the message, or send to a DLQ
        }
    }
};

export const handleQueueMessageDocs = {
    summary: 'Process SQS Queue',
    description: 'This function processes messages from an SQS queue.',
    tags: ['SQS Handlers'],
}; 