import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import redis from '../helpers/redis.js';

export const handler = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
    if (!event.body) {
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Missing request body' }),
        };
    }

    try {
        const { itemId } = JSON.parse(event.body);
        if (!itemId) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Missing itemId in request body' }),
            };
        }
        
        const item = await redis.get(`item:${itemId}`);
        if (!item) {
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'Item not found' }),
            };
        }
        return {
            statusCode: 200,
            body: JSON.stringify(item),
        };
    } catch (error) {
        console.error(error);
        if (error instanceof SyntaxError) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Invalid JSON in request body' }),
            };
        }
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' }),
        };
    }
};

export const handleApiRequestDocs = {
  summary: 'Retrieve an item by ID',
  description: 'Retrieves a specific item from the database using its ID.',
  tags: ['Items'],
  requestBody: {
    required: true,
    content: {
      'application/json': {
        schema: {
          type: 'object',
          properties: {
            itemId: {
              type: 'string',
              description: 'The ID of the item to retrieve.'
            }
          },
          required: ['itemId']
        }
      }
    }
  },
  responses: {
    '200': { 
        description: 'Successful response with the item.',
        content: {
            'application/json': {
                schema: {
                    type: 'object',
                    properties: {
                        id: { type: 'string' },
                        data: { type: 'string' }
                    }
                }
            }
        }
    },
    '400': { description: 'Bad Request: Missing or invalid request body.' },
    '404': { description: 'Item not found.' },
    '500': { description: 'Internal server error.' },
  },
};
