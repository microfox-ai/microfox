import { handleApiRequestDocs } from './functions/api-handler.js'
import { handleScheduledTaskDocs } from './functions/cron-handler.js'
import { handleQueueMessageDocs } from './functions/sqs-handler.js'

/**
 * Complete API documentation
 * This is an OpenAPI 3.0.1 definition for the agent's API.
 */
const apiDocs = {
  openapi: '3.0.1',
  info: {
    title: '<%= agentName %> API',
    version: '1.0.0',
    description: 'API for the <%= agentName %> agent.',
    contact: {
      name: 'API Support',
      email: 'support@microfox.app',
    },
  },
  servers: [
    {
      url: 'https://api.microfox.com/c/some-hash',
      description: 'Production server',
    },
  ],
  paths: {
    '/items': {
      post: handleApiRequestDocs,
    },
  },
  components: {
    schemas: {
        //...handleApiRequestDocs.components.schemas
    }
  }
}

/**
 * GET endpoint to serve API documentation.
 * This function returns the OpenAPI specification in JSON format.
 */
export const getDocs = async () => {
  try {
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify(apiDocs, null, 2),
    }
  } catch (error) {
    console.error('Error serving docs:', error)
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
      },
      body: JSON.stringify({
        error: error instanceof Error ? error.message : 'Unknown error',
      }),
    }
  }
}
