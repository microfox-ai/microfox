# <%= agentName %> Agent

This is a Microbizz agent for <%= agentName %>.

## Getting Started

### Prerequisites
- Node.js >= 20.x
- Serverless Framework
- AWS Account

### Installation
1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Configure your environment variables in `env.json`.

### Running locally
```bash
npm run dev
```

### Deployment
```bash
# Deploy to development
npm run deploy

# Deploy to production
npm run deploy:prod
```
